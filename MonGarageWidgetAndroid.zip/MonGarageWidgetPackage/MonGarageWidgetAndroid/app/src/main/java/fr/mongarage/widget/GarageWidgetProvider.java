package fr.mongarage.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class GarageWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.garage_widget);
            setClick(context, views, R.id.btn_vehicles, "vehicles", 1);
            setClick(context, views, R.id.btn_maintenance, "maintenance", 2);
            setClick(context, views, R.id.btn_history, "historyPicker", 3);
            setClick(context, views, R.id.btn_reminders, "reminders", 4);
            manager.updateAppWidget(id, views);
        }
    }
    private void setClick(Context context, RemoteViews views, int viewId, String target, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("widget_target", target);
        PendingIntent pending = PendingIntent.getActivity(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(viewId, pending);
    }
}
