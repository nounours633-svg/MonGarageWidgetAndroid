package fr.mongarage.widget;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://nounours633-svg.github.io/mon-garage/";
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String target = getIntent().getStringExtra("widget_target");
        if (target == null) target = "";
        String url = APP_URL + (target.isEmpty() ? "" : "?widget=" + Uri.encode(target));
        try {
            Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(open);
        } finally {
            finish();
        }
    }
}
